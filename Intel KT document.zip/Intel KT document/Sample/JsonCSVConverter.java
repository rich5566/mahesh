package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.apache.commons.io.FileUtils;
import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

public class JsonCSVConverter {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		JSONParser parser = new JSONParser();

		try {

			InputStream is = new FileInputStream("jsonData.txt");
			BufferedReader buf = new BufferedReader(new InputStreamReader(is));
			String line = buf.readLine();
			StringBuilder sb = new StringBuilder();
			while (line != null) {
				sb.append(line).append("\n");
				line = buf.readLine();
			}
			String jsonString = sb.toString().replace("\\", "");
			System.out.println(jsonString);

			JSONObject output=new JSONObject(jsonString);
			

			JSONArray docs = output.getJSONArray("children");

			File file = new File("fromJSON.csv");
			String csv = CDL.toString(docs);
			FileUtils.writeStringToFile(file, csv);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
